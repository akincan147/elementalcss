document.addEventListener("DOMContentLoaded", function() {
    // Specify the base URL for images
    const baseUrl = 'images/';

    // Start with image number 1
    let imageNumber = 1;

    // Function to check if an image exists
    function imageExists(url, callback) {
        const img = new Image();
        img.onload = function() {
            callback(true);
        };
        img.onerror = function() {
            callback(false);
        };
        img.src = url;
    }

    // Function to add images to the album list dynamically
    function addImageToAlbumList(imageNumber) {
        const imageExtensions = ['jpg', 'jpeg', 'png', 'gif'];
        for (const extension of imageExtensions) {

            const imageUrl = `${baseUrl}${imageNumber}.${extension}`;

            imageExists(imageUrl, function(exists) {
                if (exists) {
                    const albumList = document.getElementById('albumList');
                    const colElement = document.createElement('div');
                    colElement.classList.add('col');

                    const cardElement = document.createElement('div');
                    cardElement.classList.add('card', 'text-bg-dark');
                    cardElement.setAttribute('role', 'button');

                    const imgElement = document.createElement('img');
                    imgElement.classList.add('card-img');
                    imgElement.src = imageUrl;
                    imgElement.alt = `Image ${imageNumber}`;

                    // Add onclick dynamically
                    cardElement.onclick = function() {
                        setBackground(imageUrl);
                        // Save the background image URL to local storage
                        localStorage.setItem('backgroundImage', imageUrl);
                    };

                    cardElement.appendChild(imgElement);
                    colElement.appendChild(cardElement);
                    albumList.appendChild(colElement);

                    // Increment image number for the next iteration
                    addImageToAlbumList(imageNumber + 1);
                } else {
                    console.log(`No image found for ${imageUrl}. Stopping.`);
                }
            });
        }
    }

    // Start the process with the initial image number
    addImageToAlbumList(imageNumber);      
    
    // Check if there is a background image in local storage
    const storedBackgroundImage = localStorage.getItem('backgroundImage');
    if (storedBackgroundImage) {
        setBackground(storedBackgroundImage);
    }

    function setBackground(imageUrl) {
        $('body, html').css({
            'background-image': 'url(' + imageUrl + ')',
            'background-size': 'cover',
            'background-position': 'center',
            'background-repeat': 'no-repeat',
            'background-attachment': 'fixed'
        });            
    }
});